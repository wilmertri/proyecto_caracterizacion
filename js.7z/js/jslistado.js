$(document).ready(function() {
    $('#mitabla').dataTable( {
        "pagingType": "full_numbers"
    } );
} );